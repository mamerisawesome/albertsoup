from distutils.core import setup

setup(
    name='AlbertSoup',
    version='0.1dev',
    packages=['src/albertsoup',],
    license='',
    long_description=open('README.txt').read(),
)
